
export default class GamePlay extends Phaser.Scene {


  constructor() {
    super({ key: "GamePlay" });
  }

  create() {
    console.log("create:gameplay");


  }
}
