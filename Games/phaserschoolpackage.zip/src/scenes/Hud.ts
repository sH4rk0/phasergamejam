import GamePlay from "./GamePlay";

export default class Hud extends Phaser.Scene {


  constructor() {
    super({
      key: "Hud",
    });
  }

  preload() { }

  create() {
    console.log("create:HUD")


  }
}
