export default class GameOver extends Phaser.Scene {


  constructor() {
    super({
      key: "GameOver",
    });
  }

  create() {

    console.log("Create:gameover")


  }


}
